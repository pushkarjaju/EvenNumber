using System;
using Xunit;
using Moq;
using System.IO;

namespace EvenNumbersConsoleApp.Tests
{
    public class EvenNumbersTest
    {
        private EvenNumbers evenNumbers = new EvenNumbers();
        public EvenNumbersTest()
        {

        }

        [Fact]
        public void IsNumberEven_ReturnsTrue()
        {
            // Act 
            var expectedResult = evenNumbers.IsNumberEven(4);

            // Assert
            Assert.True(expectedResult);
        }

        [Theory]
        [InlineData(5)]
        public void IsNumberEven_ReturnsFalse(int num)
        {
            // Act 
            var expectedResult = evenNumbers.IsNumberEven(num);

            // Assert
            Assert.False(expectedResult);
        }

        [Fact]
        public void ReadInputFile_ReturnTrue_Success()
        {
            // Arrange
            Mock<StreamReader> mockFile = new Mock<StreamReader>();
            mockFile.Setup(x => x.ReadLine()).Returns("1");

            var mockEvenNumbers = new Mock<EvenNumbers>();
            mockEvenNumbers.Setup(x => x.WriteToOutputFile(It.IsAny<Int32>()));
            mockEvenNumbers.Setup(x => x.IsNumberEven(It.IsAny<Int32>())).Returns(true);

            // Act
            var expectedResult = evenNumbers.ReadInputFile();

            // Assert
            Assert.True(expectedResult);
        }
    }
}
