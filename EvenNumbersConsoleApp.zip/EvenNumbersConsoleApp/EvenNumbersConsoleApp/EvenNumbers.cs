﻿using System;
using System.IO;

namespace EvenNumbersConsoleApp
{
    public class EvenNumbers
    {
        static readonly string inputTextFilePath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..\\..\\..\\")) + @"InputFile.txt";
        static readonly string outputTextFilePath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..\\..\\..\\")) + @"OutputFile.txt";

        public EvenNumbers()
        {
        }

        /// <summary>
        /// This method will read all numbers from an input file and extract only even number and write it to output file
        /// </summary>
        public bool ReadInputFile()
        {
            try
            {
                // check if file exists
                if (File.Exists(inputTextFilePath))
                {
                    using StreamReader file = new StreamReader(inputTextFilePath);
                    string ln;
                    while ((ln = file.ReadLine()) != null)
                    {
                        // check if number is even
                        if (!string.IsNullOrWhiteSpace(ln) &&
                            int.TryParse(ln, out int num) &&
                            IsNumberEven(Convert.ToInt32(ln)))
                        {
                            // write number in an output file
                            WriteToOutputFile(Convert.ToInt32(ln));
                        }
                    }
                    file.Close();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method will write all even number into an output file
        /// </summary>
        /// <param name="number">The number in from an input file</param>
        public virtual void WriteToOutputFile(int number)
        {
            try
            {
                // check if file exists
                if (File.Exists(outputTextFilePath))
                {
                    File.AppendAllText(outputTextFilePath, number + Environment.NewLine);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method will check if number is even or not
        /// </summary>
        /// <param name="number">The number in from an input file</param>
        /// <returns>True or False</returns>
        public virtual bool IsNumberEven(int number)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(number.ToString()))
                {
                    return number % 2 == 0 ? true : false;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
