﻿using System;

namespace EvenNumbersConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please wait, File is Processing...");
                EvenNumbers evenNumbers = new EvenNumbers();
                evenNumbers.ReadInputFile();
                Console.WriteLine("Writting to File is complete");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
